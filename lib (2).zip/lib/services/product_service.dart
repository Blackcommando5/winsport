import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product_model.dart';

class ProductService {
  final _productRef = FirebaseFirestore.instance.collection('products');

  Future<List<ProductModel>> getProductsByCategory(String category) async {
    final snapshot = await _productRef
        .where('category', isEqualTo: category)
        .get();
    return snapshot.docs
        .map((doc) => ProductModel.fromMap(doc.data(), doc.id))
        .toList();
  }
}
