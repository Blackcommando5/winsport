import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/cart_item_model.dart';

class CartProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String userId; // mutable now

  //CartProvider({required this.userId});

  CartProvider({required this.userId}) {
    print('🛒 CartProvider created for user: $userId');
  }

  List<CartItemModel> _cartItems = [];

  List<CartItemModel> get cartItems => _cartItems;

  int get totalItems => _cartItems.fold(0, (sum, item) => sum + item.quantity);

  int get totalPrice =>
      _cartItems.fold(0, (sum, item) => sum + (item.price * item.quantity));

  /// Update userId and refresh cart
  void updateUserId(String newUserId) {
    if (userId != newUserId) {
      userId = newUserId;
      fetchCart(); // load cart for new user
    }
  }

  void setCartItems(List<CartItemModel> items) {
    _cartItems.clear();
    _cartItems.addAll(items);
    notifyListeners();
  }

  /// Load cart from Firebase
  Future<void> fetchCart() async {
    if (userId.isEmpty) {
      _cartItems = [];
      notifyListeners();
      return;
    }

    final snapshot = await _firestore
        .collection('users')
        .doc(userId)
        .collection('cart')
        .get();

    _cartItems = snapshot.docs
        .map((doc) => CartItemModel.fromDoc(doc.id, doc.data()))
        .toList();

    notifyListeners();
  }

  /// Add item to Firebase cart or increment quantity
  Future<void> addToCart(CartItemModel item) async {
    if (userId.isEmpty) return;

    final docRef = _firestore
        .collection('users')
        .doc(userId)
        .collection('cart')
        .doc(item.productId);

    final doc = await docRef.get();

    if (doc.exists) {
      final existing = CartItemModel.fromDoc(doc.id, doc.data()!);
      final updated = existing.copyWith(quantity: existing.quantity + 1);
      await docRef.set(updated.toMap());
    } else {
      await docRef.set(item.toMap());
    }

    await fetchCart(); // refresh and notifyListeners
  }

  /// Decrease quantity or remove if 1
  Future<void> decreaseQuantity(String productId) async {
    if (userId.isEmpty) return;

    final docRef = _firestore
        .collection('users')
        .doc(userId)
        .collection('cart')
        .doc(productId);

    final doc = await docRef.get();

    if (!doc.exists) return;

    final existing = CartItemModel.fromDoc(doc.id, doc.data()!);

    if (existing.quantity > 1) {
      final updated = existing.copyWith(quantity: existing.quantity - 1);
      await docRef.set(updated.toMap());
    } else {
      await docRef.delete();
    }

    await fetchCart();
  }

  /// Remove item completely from cart
  Future<void> removeFromCart(String productId) async {
    if (userId.isEmpty) return;

    await _firestore
        .collection('users')
        .doc(userId)
        .collection('cart')
        .doc(productId)
        .delete();

    await fetchCart();
  }

  /// Clear all items from cart
  Future<void> clearCart() async {
    if (userId.isEmpty) return;

    final cartRef = _firestore
        .collection('users')
        .doc(userId)
        .collection('cart');

    final snapshot = await cartRef.get();

    for (final doc in snapshot.docs) {
      await doc.reference.delete();
    }

    _cartItems.clear();
    notifyListeners();
  }
}
