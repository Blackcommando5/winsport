import 'package:flutter/material.dart';

final ThemeData appThemeData = ThemeData(
  primarySwatch: Colors.deepOrange,
  fontFamily: 'Roboto',
  scaffoldBackgroundColor: Colors.white,
);
