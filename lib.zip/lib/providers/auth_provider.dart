import 'package:flutter/material.dart';

class AuthProvider extends ChangeNotifier {
  // Your login status, user info, etc.
}
