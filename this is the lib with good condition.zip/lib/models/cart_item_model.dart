class CartItemModel {
  final String productId;
  final String imageUrl;
  final String name;
  final double price; // <-- Changed to double
  final int quantity;

  CartItemModel({
    required this.productId,
    required this.imageUrl,
    required this.name,
    required this.price,
    required this.quantity,
  });

  factory CartItemModel.fromDoc(String id, Map<String, dynamic> data) {
    final rawPrice = data['price'];
    final price = (rawPrice is int)
        ? rawPrice.toDouble()
        : (rawPrice is double ? rawPrice : 0.0);

    return CartItemModel(
      productId: id,
      imageUrl: data['imageUrl'] ?? '',
      name: data['name'] ?? '',
      price: price,
      quantity: (data['quantity'] as num).toInt(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'imageUrl': imageUrl,
      'name': name,
      'price': price,
      'quantity': quantity,
    };
  }

  CartItemModel copyWith({int? quantity}) {
    return CartItemModel(
      productId: productId,
      imageUrl: imageUrl,
      name: name,
      price: price,
      quantity: quantity ?? this.quantity,
    );
  }
}
