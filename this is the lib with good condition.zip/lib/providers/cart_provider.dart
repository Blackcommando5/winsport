import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/cart_item_model.dart';

class CartProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  String userId;

  CartProvider({required this.userId});

  List<CartItemModel> _cartItems = [];
  List<CartItemModel> get cartItems => _cartItems;

  int get totalItems => _cartItems.fold(0, (sum, item) => sum + item.quantity);
  double get totalPrice =>
      _cartItems.fold(0.0, (sum, item) => sum + item.quantity * item.price);

  void updateUserId(String newUserId) {
    if (userId != newUserId) {
      userId = newUserId;
      fetchCart();
    }
  }

  Future<void> fetchCart() async {
    if (userId.isEmpty) return;

    final snapshot = await _firestore
        .collection('users')
        .doc(userId)
        .collection('cart')
        .get();

    _cartItems = snapshot.docs
        .map((doc) => CartItemModel.fromDoc(doc.id, doc.data()))
        .toList();

    notifyListeners();
  }

  Future<void> addToCart(CartItemModel item) async {
    final docRef = _firestore
        .collection('users')
        .doc(userId)
        .collection('cart')
        .doc(item.productId);
    final doc = await docRef.get();

    if (doc.exists) {
      final existing = CartItemModel.fromDoc(doc.id, doc.data()!);
      final updated = existing.copyWith(quantity: existing.quantity + 1);
      await docRef.set(updated.toMap());
    } else {
      await docRef.set(item.toMap());
    }

    await fetchCart();
  }

  Future<void> decreaseQuantity(String productId) async {
    final docRef = _firestore
        .collection('users')
        .doc(userId)
        .collection('cart')
        .doc(productId);
    final doc = await docRef.get();

    if (!doc.exists) return;

    final existing = CartItemModel.fromDoc(doc.id, doc.data()!);
    if (existing.quantity > 1) {
      await docRef.set(
        existing.copyWith(quantity: existing.quantity - 1).toMap(),
      );
    } else {
      await docRef.delete();
    }

    await fetchCart();
  }

  Future<void> removeFromCart(String productId) async {
    await _firestore
        .collection('users')
        .doc(userId)
        .collection('cart')
        .doc(productId)
        .delete();
    await fetchCart();
  }

  Future<void> clearCart() async {
    final snapshot = await _firestore
        .collection('users')
        .doc(userId)
        .collection('cart')
        .get();

    for (final doc in snapshot.docs) {
      await doc.reference.delete();
    }

    _cartItems.clear();
    notifyListeners();
  }
}
