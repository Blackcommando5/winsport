import 'package:flutter/material.dart';

class AuthProvider with ChangeNotifier {
  String? _userId;

  String? get userId => _userId;

  void setUserId(String id) {
    _userId = id;
    notifyListeners(); // ✅ So CartProvider updates too
  }

  // Add login/signup logic too here, where _userId gets set
}
